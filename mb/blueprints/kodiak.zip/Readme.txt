These are just the raw .dat files I used to create the Kodiak.
They haven't been cleaned at all.
Inline .dat is kodiak1.dat.
kodpose1.dat has the rocket pack and rifle included.
I hope to have these files fixed up later, but for now this is it.

Thanks,
Ben Vaughan
buster@marsbase.com
www.marsbase.com
----------------
The few, the proud,...the plasitc.