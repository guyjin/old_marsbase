In ldraw, view crusader.dat or crusaopn.dat. 
On shows the canopy open (crusaopn.dat) and the other shows it closed.

These images are all copyright Ben Vaughan and are in no way associated with LEGO A/G.