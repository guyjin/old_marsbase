These plans are in a jpeg format and can be viewed with any web brower.  
Questions can be directed to:
buster@marsbase.com

These plans are free for any non-profit use.

Thanks,
Ben Vaughan
http://www.marsbase.com
